import java.lang.Exception;
import java.util.ArrayList;
import java.util.List;

public class Rocket {
    private String id;
    private List<Propeller> propellers = new ArrayList<>();



    public Rocket(String id) throws Exception {
        if (id.equals("")) throw new Exception();
        this.id = id;

    }

    public void addPropeller(Propeller p){
        propellers.add(p);
    }



    public List<Propeller> getPropellers() {
        return propellers;
    }

    public String getId() {
        return id;
    }


}





